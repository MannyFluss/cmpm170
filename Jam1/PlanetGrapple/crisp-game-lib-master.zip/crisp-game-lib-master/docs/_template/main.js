title = "";

description = `
`;

characters = [];

options = {};

function update() {
  if (!ticks) {
  }
}
